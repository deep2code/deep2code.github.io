from typing import Union

from fastapi import FastAPI

from pydantic import BaseModel

# async def app(scope, receive, send):
app = FastAPI()


class Item(BaseModel):
    name: str
    price: float
    is_offer: Union[bool, None] = None


@app.get("/")
def read_root():
    return {"Hello": "World"}


@app.get("/items/{item_id}")
async def read_item(item_id: int, q: Union[str, None] = None):
    return {"item_id": item_id, "q": q}


@app.put("/items/{item_id}")
def update_item(item_id: int, item: Item):
    return {"item_id": item_id, "item": item}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", reload=True)
